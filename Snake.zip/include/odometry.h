#include "macros.h"
// using namespace vex;
// class Odom{
// private:
// #define get_left L_ODOM.rotation(rotationUnits::raw)
// #define get_right R_ODOM.rotation(rotationUnits::raw)
// #define get_back B_ODOM.rotation(rotationUnits::raw)
// #define clear_left L_ODOM.resetRotation()
// #define clear_right R_ODOM.resetRotation()
// #define clear_back B_ODOM.resetRotation()
//   double d_scale=1720,t_scale=3.5;
//   double cosDegrees(double deg){
//     return cos(deg/360*2*PI);
//   }
//   double sinDegrees(double deg){
//     return sin(deg/360*2*PI);
//   }
//   task* track;
//   task* base;
// public:
//   long pos_x;
//   long pos_y;
//   long theta;
  
//   Odom(long start_x,long start_y,long start_theta){
//     pos_x=start_x;pos_y=start_y;theta=start_theta;
//   }
//   void reset(){
//     clear_left;
//     clear_right;
//     clear_back;
//     pos_x=0;
//     pos_y=0;
//     theta=0;
//   }
//   void set_scale(double sc, double tc){
//     d_scale=sc;
//     t_scale=tc;
//   }
//   void start_collection(){
//     reset();
//     track=new task(trackOdometry());
//     base=new task(base_control());
//   }
//   void kill(){
//     track->stop();
//     base->stop();
//   }
//   task base_control(){
//     reset();
//     int target_left=0,target_right=0,target_theta=0;
    
//   }
  
//   void driveTo(long target_x,long target_y,long target_theta){
    
//   }
//   task trackOdometry(){
//   long lastLeft, lastRight, leftTicks, rightTicks,lastBack,backTicks;

//   double leftMM, rightMM, mm,backMM;

//   long leftSample, rightSample,backSample;
//   while (true)
//   {
//     //Save quads
//     leftSample = get_left;
//     rightSample = get_right;
//     backSample=get_back;

//     //Get delta
//     leftTicks = leftSample - lastLeft;
//     rightTicks = rightSample - lastRight;
//     backTicks=backSample-lastBack;

//     //Save last vals
//     lastLeft = leftSample;
//     lastRight = rightSample;
//     lastBack=backSample;
//     //Convert to mm
//     leftMM = (double)leftTicks / d_scale;
//     rightMM = (double)rightTicks / d_scale;
//     backMM=(double)backTicks/t_scale;
//     //Get avg delta
//     mm = (leftMM + rightMM) / 2.0;

//     //Get theta
//     theta += (rightTicks - leftTicks) / t_scale;

//     //Wrap theta
//     if(theta > 180)
//       theta -= 360;
//     if(theta <= -180)
//       theta += 360;

//     //Do the odom math
//     pos_x += mm * cosDegrees(theta);
//     pos_y += mm * sinDegrees(theta);

//     //Save to global
//     wait(5);
//   }
// }
// };



