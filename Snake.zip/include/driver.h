#include "motion.h"

//Constants for Lift Position for Towers
#define DESCORE_POS 300
#define LOW_GOAL 426
#define HIGH_GOAL 600
//bool holdMode = false;
int swapper = 0;
bool intake = true;

//Initialization for slew rate control
void init() {
	for (int i = 0; i < 4; i++)curr[i] = 0;
  Roller.setBrake(brakeType::hold);
  Roller2.setBrake(brakeType::hold);
    //clear(Deploy);
  hold(Lift1);
}

//2 Different Drive Speeds
bool full_speed = false,lift_hold=false,st=false;

int curr_lift=0; //0=bottom, 1=low towers, 2=high tower
void change_straight(){
  st=!st;
}

bool lifting=false;
bool cube_lock=false;
void change_lock(){
  cube_lock=!cube_lock;
  ct.rumble("--");
}
void lift_high(){
  lifting=true;
  if(get2(Lift1)<100){
    //Roller.rotateFor(-40,rotationUnits::deg,45,velocityUnits::pct,false);
    //Roller2.rotateFor(-40,rotationUnits::deg,45,velocityUnits::pct,false);
    //setRoller(0);
    if(cube_lock)setRoller(-35);
    
    LIFT(HIGH_GOAL,cube_lock);
    lifting=false;
  }
  else LIFT2(),lifting=false;
}
void lift_low(){
  lifting=true;
  if(get2(Lift1)<100){
    if(cube_lock)setRoller(-15),wait(40);
    LIFT(LOW_GOAL,cube_lock);
    lifting=false;
  }
  else LIFT2(),lifting=false;
}

void changeSpeed() {
	full_speed = !full_speed;
}

bool sign(int x) {
	return x > 0;
}
//bool fast=false;
void roller_intake(){
  if(curr_roller<=0)setRoller(100),curr_roller=1;
  else setRoller(0),curr_roller=0,fast=false;
}

bool ppp=false;
bool tower=0;
void change_mode(){
  tower=!tower;
  if(tower)pt.rumble("--");
}
int lastLine=LS.value(analogUnits::range12bit);

void run() {

	//Drive Base Control
		if (!full_speed)cap = 60, add = 7;
	else cap=100,add = 40;
  if(P(ButtonUp))setM(Lift1,-50);
  else if(!lifting)setM(Lift1,0);
	//drfb
  if(P(ButtonA)||PP(ButtonB))clear(Deploy);
	if (P(ButtonRight)||PP(ButtonL1))hold(Deploy),setRoller(0),curr_roller=0,set_deploy();
	else if (P(ButtonDown)||PP(ButtonL2))coast(Deploy),set_deploy2();
	else setM(Deploy, 0);
  if(get(Deploy)>1000)cubeCount=0;

  //if(P(ButtonUp) || PP(ButtonUp))LIFT(600);
  //else if(P(ButtonDown) || PP(ButtonDown))LIFT2();
  //else if(P(ButtonLeft) || PP(ButtonLeft))LIFT(420);
  if(abs(lastLine-LS.value(analogUnits::range12bit))>100)cubeCount++;
  cubeCount=min(cubeCount,12);
  
  
  lastLine=LS.value(analogUnits::range12bit);
}

