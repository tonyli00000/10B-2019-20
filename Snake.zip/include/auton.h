#include "driver.h"
#include "autonFunc.h"
using namespace vex;
#define AUTON_NUM 8
#define LIFT_CONSTANT 1000
#define ROLLER_CONSTANT 210
string auton_description[AUTON_NUM]={"8 Cube Unprotected Red","6 Cube Protected Red","6 Cube Unprotected Red","Prog Skills","8 Cube Unprotected Blue","6 Cube Protected Red","6 Cube Unprotected Red","BLANK"};
void Red1(task*& Drive, task*& S,bool skills=false){
 
    init_auton();
  Drive->resume();
  S->resume();
  
  setRoller(100);
  setM(Lift1,-2);
  driveTile(1.4,40);
  wait(1800);
  drive(0,0);
  wait(50);
  setM(Lift1,0);
  driveTile(-0.27);
  wait(650);
  turnDeg(-43.5,50);
  wait(1050);
  drive(-2450,-3050);
  //velCap=80;
  wait(2300);
  drive(0,0);
  wait(120);
  setM(Lift1,-10);
  driveTile(1.45,60);
  wait(1900);
  drive(0,0);
  wait(120);
  turnDeg(141);
  wait(600);
  
  wait(650);
  setRoller(0);
   drive(0,0);
   //wait(100);
   
   
    Deploy.rotateFor(1200,rotationUnits::deg,60,velocityUnits::pct,false);
   // drive(1600,1800);
    driveTile(1.1,80);
   wait(600);
   Roller.rotateFor(-50,rotationUnits::deg,60,velocityUnits::pct,false);
   Roller2.rotateFor(-50,rotationUnits::deg,60,velocityUnits::pct,false);
    wait(700);
     setM(Lift1,0);
     Drive->suspend();
    auton_deploy(8);
  
  Drive->resume();
   setRoller(-40);
  driveTile(-1,30);
   if(!skills)end_auton();
}
//Scratched
void Red2(task*& Drive, task*& S){
     Drive->suspend();
  S->suspend();
     init_auton();
    
   setM(Deploy,0);
   setM(Lift1,0);
  Drive->resume();
  S->resume();
    velCap=100;
  drive(800,1340);
  wait(1000);
  drive(1400,800);
  wait(1300);
  drive(0,0);
  wait(200);
  setRoller(100);
   Drive->suspend();
  S->suspend();
  setLeft(100);
  setRight(100);
  wait(480);
  setLeft(0);
  setRight(0);
   setRoller(100);
  setM(Deploy,0);
  //wait(1300);
  setRoller(100);
  wait(900);
  //riveTile(1.2,50);
  //wait(1500);
  //drive(0,0);
  //wait(100);
  //Drive->suspend();
  //S->suspend();
  //setLeft(100);
  //setRight(100);
  
  //wait(500);
  //setLeft(0);
  //setRight(0);
  Drive->resume();
  S->resume();
  //setRoller(40);
  //driveTile(-0.5,80);
  wait(700);
  driveTile(-0.45,90);
  wait(700);
  setRoller(100);
  
  
  turnDeg(-35,80);
  wait(700);
  driveTile(0.4,100);
  wait(900);
  driveTile(-0.4,100);
  wait(600);
  turnDeg(30,80);
  wait(800);
  driveTile(-0.68);
  wait(800);
  turnDeg(-114);
  wait(1300);
    driveTile(0.7,100);
  wait(800);


   end_auton();
}
void Red3(task*& Drive, task*& S,bool skills=false){
//  Drive->suspend();
//   S->suspend();
//     //setLeft(-10);
//     //setRight(-10);
//     init_auton();
//     //wait(250);
//     //setM(Deploy,-80);
//   wait(250);
//   setM(Deploy,0);
//   wait(150);
//     setRoller(100);
//   setRoller(100);
//   Drive->resume();
//   S->resume();
//   //setM(Deploy,100);
//   get4cubes_straight();
//   turnDeg(-30,80);
//   wait(700);
//   driveTile(0.6,90);
//   wait(840);
//   driveTile(-0.6,90);
//   wait(720);
//   turnDeg(27,80);
//   wait(700);
//   driveTile(-0.9,60);
//   wait(1000);
//   turnDeg(130,100);
//   coast(Roller);
//   coast(Roller2);
//   Roller.startRotateFor(-240,rotationUnits::deg,-180,velocityUnits::pct);
//   Roller2.startRotateFor(-240,rotationUnits::deg,-180,velocityUnits::pct);
//   wait(1200);
  
//    stop_drive();
//   driveTile(0.92,100);
//    Deploy.startRotateFor(300,rotationUnits::deg);
//   setRoller(1);
//    wait(950);
//    setRoller(-10);
//    Drive->suspend();
//    S->suspend();
//    setLeft(-45);
//    setRight(-45);
//    wait(120);
//    setLeft(0);
//    setRight(0);
//    setRoller(0);
//    wait(200);
//    setRoller(-35);
//    wait(260);
//    setRoller(0);
//    auton_deploy(1);
//   hold(Deploy);
  
//   setRoller(-50);
//   wait(150);
//    setLeft(-30);
//    setRight(-30);
  drive(1550,2000);
   end_auton();
}
//Prog Skills
void Red4(task*& Drive, task*& S){
  
  add=25;
  Drive->suspend();
  S->suspend();
  
  init_auton(); //Auton Deploy
  
  //Wall Align
   setLeft(-20);
   setRight(-20);
   wait(1000);
  Drive->resume();
  S->resume();
  
  setRoller(100);
  /*Do first tower if there's enough time*/
  // cube_lock=false;
  // wait(500);
  // setRoller(0);
  // turnDeg(40);
  // lift_low();
  // wait(500);
  // driveTile(0.9);
  // wait(900);
  // setRoller(-100);
  // wait(500);
  //   driveTile(-0.9);
  // wait(900);
  // turnDeg(-37);
  // wait(900);
  // LIFT2();
  cube_lock=true;
  
  /*First Line of Cube*/
  setM(Lift1,-2);
  driveTile(1.805,40);
  wait(3500);
  drive(0,0);
  wait(2300);
  setRoller(0);
  wait(200);

  /*First Tower*/
  turnDeg(7);
  lift_low();
  turnDeg(-23);
  wait(900);
  driveTile(0.12,100);
  wait(400);
  setRoller(-60);
  wait(600);
  driveTile(-0.12);
  wait(600);
  turnDeg(28);
  wait(450);
  setRoller(100);
  LIFT2();

  /*Second Line*/
  driveTile(0.34,40);
  wait(600);
  turnDeg(-10);
  wait(800);
  setM(Lift1,-10);
  driveTile(2.3,45);
  wait(4600);
  drive(0,0);
  wait(1000);
  setRoller(0);
  wait(120);
  driveTile(-0.1,60);
  setRoller(0);
  wait(400);

  /*Second Tower*/
    lift_low();
  turnDeg(88,60);
  wait(1500);
  setRoller(-80);
  wait(700);
  turnDeg(-83,70);
  wait(1000);
  setRoller(100);
  LIFT2();
  driveTile(0.56,60);
  wait(1000);
  driveTile(-0.13,60);
  wait(1200);
  turnDeg(41);
  wait(1000);
  driveTile(0.54);
  wait(1500);
  setRoller(0);

  //Deploy
     Drive->suspend();
   S->suspend();
   wait(300);
       Roller.rotateFor(-134,rotationUnits::deg,60,velocityUnits::pct,false);
   Roller2.rotateFor(-134,rotationUnits::deg,60,velocityUnits::pct,false);
   wait(1100);

  auton_deploy(1,true);
  Drive->resume();
  S->resume();
  driveTile(-0.47,60);
  wait(1000);
  setM(Deploy,-100);
  wait(2000);
  setM(Deploy,0);
  // lift_high();
  // turnDeg(45);
  // wait(900);
  // driveTile(0.8,40);
  // wait(1300);
  // driveTile(-0.5);
  // wait(1000);
  // turnDeg(27);
  // wait(900);
  // driveTile(-1.5);
  // wait(1900);
  // turnDeg(66);
  // wait(1000);
  // driveTile(-0.2,30);
  // setRoller(100);
  // LIFT2();
  
  turnDeg(-133,40);
  wait(2500);

  /*Third Tower*/
  setM(Deploy,0);
  setRoller(60);
  driveTile(1.01,60);
  wait(1500);
  driveTile(-0.2);
  wait(600);
  setRoller(-30);
  wait(510);
  setRoller(0);
  cube_lock=false;
  lift_high();
  //wait(150);
  driveTile(0.3,100);
  wait(500);
  setRoller(-70);
  wait(800);
  driveTile(-0.74);
  turnDeg(-90);
  wait(1200);
  driveTile(-0.9,60);
  setRoller(100);
  LIFT2();
  wait(1300);
  cube_lock=true;
  
  driveTile(4,50);
  wait(5000);
  end_auton();
}
void Blue1(task*& Drive, task*& S){
    init_auton();
  Drive->resume();
  S->resume();
  
  setRoller(100);
  setM(Lift1,-2);
  driveTile(1.43,35);
  wait(1800);
  drive(0,0);
  wait(50);
  setM(Lift1,0);
  driveTile(-0.29);
  wait(550);
  turnDeg(46,50);
  wait(1050);
  drive(-3270,-2670);
  //velCap=80;
  wait(2000);
  drive(0,0);
  wait(100);
  setM(Lift1,-10);
  driveTile(1.45,60);
  wait(1900);
  drive(0,0);
  wait(60);
  turnDeg(-136.5);
  wait(600);
  
  wait(700);
  setRoller(0);
   drive(0,0);
   wait(100);
   
   
    Deploy.rotateFor(900,rotationUnits::deg,55,velocityUnits::pct,false);
   // drive(1700,1700);
    driveTile(1.1,60);
   wait(600);
   Roller.rotateFor(-70,rotationUnits::deg,60,velocityUnits::pct,false);
   Roller2.rotateFor(-70,rotationUnits::deg,60,velocityUnits::pct,false);
    wait(800);
     setM(Lift1,0);
     Drive->suspend();
    auton_deploy(8);
  
  Drive->resume();
   setRoller(-40);
  driveTile(-1,30);
   end_auton();
}
void Blue2(task*& Drive, task*& S){
   Drive->suspend();
  S->suspend();
     init_auton();
    
   setM(Deploy,0);
   setM(Lift1,0);
  Drive->resume();
  S->resume();
   setRoller(100);
  setM(Deploy,0);
  //wait(1300);
  setRoller(100);
  driveTile(1.32,50);
  wait(1500);
  setRoller(40);
  //driveTile(0.26,80);
  //wait(700);
  driveTile(-0.3,50);
  wait(700);
  setRoller(100);
  
  driveTile(1.0,80);
  wait(1500);
  driveTile(-0.5,100);
  wait(600);
  turnDeg(30,80);
  wait(700);
  driveTile(0.4,100);
  wait(900);
  driveTile(-0.4,100);
  wait(600);
  turnDeg(-35,80);
  wait(800);
  driveTile(-0.88);
  wait(1200);
  turnDeg(-85);
  wait(1000);
    driveTile(0.7,100);
  wait(800);
  driveTile(-0.6);
  wait(600);
  turnDeg(170);
  wait(1300);
  drive(0,0);
  wait(200);
  driveTile(1);

   end_auton();
}
void Blue3(task*& Drive, task*& S,bool skills=false){
  Drive->suspend();
  S->suspend();
    setLeft(-10);
    setRight(-10);
    init_auton();
    //wait(250);
    //setM(Deploy,-80);
  wait(250);
  setM(Deploy,0);
  wait(150);
    setRoller(100);
  setRoller(100);
  Drive->resume();
  S->resume();
  //setM(Deploy,100);
  get4cubes_straight();
  turnDeg(30,80);
  wait(700);
  driveTile(0.6,90);
  wait(840);
  driveTile(-0.6,90);
  wait(720);
  turnDeg(-27,80);
  wait(700);
  driveTile(-0.9,60);
  wait(1000);
  turnDeg(-130,100);
  coast(Roller);
  coast(Roller2);
  Roller.startRotateFor(-240,rotationUnits::deg,-180,velocityUnits::pct);
  Roller2.startRotateFor(-240,rotationUnits::deg,-180,velocityUnits::pct);
  wait(1200);
  
   stop_drive();
  driveTile(0.92,100);
   Deploy.startRotateFor(300,rotationUnits::deg);
  setRoller(1);
   wait(950);
   setRoller(-10);
   Drive->suspend();
   S->suspend();
   setLeft(-45);
   setRight(-45);
   wait(120);
   setLeft(0);
   setRight(0);
   setRoller(0);
   wait(200);
   setRoller(-35);
   wait(260);
   setRoller(0);
   auton_deploy(1);
  hold(Deploy);
  
  setRoller(-50);
  wait(150);
   setLeft(-30);
   setRight(-30);
   end_auton();
}
void Blue4(task*& Drive, task*& S){
   Drive->suspend();
  S->suspend();
  //    init_auton();
    setRoller(100);
    setLeft(0);
    setRight(60);
    wait(600);
    setRight(100);
    setLeft(-5);
  //  setM(Deploy,0);
  //  setM(Lift1,0);
  // Drive->resume();
  // S->resume();
  // velCap=100;
  // drive(800,1200);
  // wait(1000);
  // drive(1300,800);
  // wait(1000);
  // drive(0,0);
  // wait(200);
  // setRoller(100);
  //  Drive->suspend();
  // S->suspend();
  // setLeft(100);
  // setRight(100);
  // wait(400);
  // setLeft(0);
  // setRight(0);
  // setRoller(100);
  //  driveTile(0.5,40);
  //  lift_high();
  //  wait(300);
  //  drive(0,0);
  //  wait(200);
  //  turnDeg(-12,30);
  //  wait(900);
  //  driveTile(0.52,40);
  //  wait(1000);
  //  setRoller(100);
  //  setM(Lift1,-50);
  //  wait(1600);
  //  //setM(Lift1,0);
  //  turnDeg(-5,30);
  //  wait(500);
  //  setM(Lift1,0);
  //  driveTile(0.9,100);
  //  wait(1200);
  //  drive(0,0);
  //  wait(200);
  //  driveTile(-0.65);
  //  wait(900);
  //  turnDeg(-94,60);
  //  wait(1500);
  //  Deploy.startRotateFor(600,rotationUnits::deg);
  //  driveTile(1.4,100);
  //  wait(1500);
  //  Drive->suspend();
  //  S->suspend();
  //  setRoller(0);
  //  auton_deploy(2);
  end_auton();
}