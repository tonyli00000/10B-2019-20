using namespace vex;

brain       Brain;
motor Left=motor(PORT6);
motor Right=motor(PORT15,true);
motor Left2=motor(PORT14);
motor Right2=motor(PORT12,true);

motor Roller=motor(PORT11);
motor Roller2=motor(PORT13,true);

motor Lift1=motor(PORT19,true);
motor Deploy=motor(PORT8);

analog_in LS=analog_in(Brain.ThreeWirePort.G);
controller ct = controller();
controller pt = controller(controllerType::partner);
vex::inertial    Inertial( vex::PORT7 );
// encoder L_ODOM = encoder(Brain.ThreeWirePort.A);
// encoder R_ODOM = encoder(Brain.ThreeWirePort.C);
// encoder B_ODOM = encoder(Brain.ThreeWirePort.E);

competition Competition;
bool fast=false;