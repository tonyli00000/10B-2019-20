#include "motion.h"

//Constants for Lift Position for Towers
#define DESCORE_POS 300
#define LOW_GOAL 300
#define HIGH_GOAL 700
//bool holdMode = false;
int swapper = 0;
bool intake = true;

//Initialization for slew rate control
void init() {
	for (int i = 0; i < 4; i++)curr[i] = 0;
  Roller.setBrake(brakeType::hold);
  Roller2.setBrake(brakeType::hold);
    clear(Deploy);
}

//2 Different Drive Speeds
bool full_speed = true,lift_hold=false,st=false;

int curr_lift=0; //0=bottom, 1=low towers, 2=high tower
void change_straight(){
  st=!st;
}

void changeSpeed() {
	full_speed = !full_speed;
}

bool sign(int x) {
	return x > 0;
}
//bool fast=false;
void roller_intake(){
  if(curr_roller<=0)setRoller(100),curr_roller=1;
  else setRoller(0),curr_roller=0,fast=false;
}

bool ppp=false;
bool tower=0;
void change_mode(){
  tower=!tower;
  if(tower)pt.rumble("--");
}
int lastLine=LS.value(analogUnits::range12bit);
void run() {

	//Drive Base Control
	
  
	//drfb
  if(P(ButtonB)||PP(ButtonB))clear(Deploy);
	if (P(ButtonL1)||PP(ButtonL1))setM(Lift1,-10),hold(Deploy),setRoller(0),curr_roller=0,set_deploy();
	else if (P(ButtonL2)||PP(ButtonL2))coast(Deploy),set_deploy2(),setM(Lift1,0);
	else setM(Deploy, 0);
  if(get(Deploy)>1000)cubeCount=0;
  if(PP(ButtonR1))setM(Lift1,100),hold(Lift1);
  else if(PP(ButtonR2))setM(Lift1,-50),coast(Lift1);
  else setM(Lift1,0);
  if(P(ButtonUp) || PP(ButtonUp)){
    Deploy.rotateTo(500,rotationUnits::deg,false),wait(200);
    setRoller(0);
    hold(Deploy);
    //Deploy.rotateFor(500,rotationUnits::deg,false),wait(200);
    hold(Lift1),LIFT(850);
  }
  if(P(ButtonLeft) || PP(ButtonLeft)){
    Deploy.rotateTo(500,rotationUnits::deg,false),wait(200);
    setRoller(0);
    //hold(Deploy);
    //Deploy.rotateFor(500,rotationUnits::deg,false),wait(200);
    hold(Lift1),LIFT(710);
  }
  else if(P(ButtonDown) || PP(ButtonDown)){
    coast(Lift1),setM(Lift1,-100),wait(300),setM(Lift1,0);
    setM(Deploy,-60);
    wait(450),setM(Lift1,-10);
  }
  if(abs(lastLine-LS.value(analogUnits::range12bit))>100)cubeCount++;
  cubeCount=min(cubeCount,12);
  if(tower && curr_roller==1 && abs(lastLine-LS.value(analogUnits::range12bit))>100)setRoller(-60),wait(330),setRoller(0),curr_roller=0;
    if(P(ButtonR2) || PP(ButtonR2))setRoller(-60),curr_roller=-1;
  else if(curr_roller==-1)setRoller(0),curr_roller=0;
  
  if(P(ButtonRight)){
    setRoller(-100);
  setM(Deploy,100);
  wait(200);
  setRoller(-100);
  wait(550);
  setM(Deploy,0);
  wait(200);
  
  setM(Deploy,-100);
  //wait(200);
  setM(Deploy,-100);
  //setRoller(0);
  //wait(100);
  setM(Deploy,-80);
  wait(600);
  }
  lastLine=LS.value(analogUnits::range12bit);
}

