#include "vex.h"
#include "auton.h"
#include "autonselection.h"

/*
Before Comp To-Do: Actually READ this
Main: Remember to change DEBUG and AUTON for actual competition
Test autonselection at competition
Motion.h: Tune Tile and Turn Constants at actual competition
Motion.h: Disable gyro if inconsistent or static issues
Skills.h: Test skills
*/


//Constants for Auton Selection or Testing
#define DEBUG 1
#define AUTON 1

using namespace vex;
using namespace std;

task* Drive;
task* S;
//Sensor setup
//Odom BDOM(0,0,0);
void InertialStartCal() {
    Inertial.calibrate(); 
}

void pre_auton( void ) {
  //Odom init
  //BDOM.reset();
   InertialStartCal();
}

void autonomous( void ) {
  //BDOM.reset();
  //BDOM.start_collection();
  inUse=true;
  Drive=new task(drivePIDFn);
  S=new task(slew);
  init();

  //Taking the selected auton from global variable
  int a=autonomousSelection+1;
  if(DEBUG)a=AUTON;
  add=slewAdd;

  //Calls each autonomous routine separately
  switch(a){
    case 1:Red1(Drive,S);
    case 2:Red2(Drive,S);
    case 3:Red3(Drive,S);
    case 4:Red4(Drive,S);
    case 5:Blue1(Drive,S);
    case 6:Blue2(Drive,S);
    case 7:Blue3(Drive,S);
    case 8:Blue4(Drive,S);
  }
  wait(15000);
  
}


//vex::limit       sw1( Brain.ThreeWirePort.A );

/*----------------------------------------------------------------------------*/


void usercontrol( void ) {
  ct.ButtonUp.released(changeSpeed);
  ct.ButtonR1.released(roller_intake);
  pt.ButtonR1.released(roller_intake);
  pt.ButtonRight.released(change_straight);
  pt.ButtonX.released(change_mode);
  inUse=false; //Ensuring Autonomous PID doesn't run 
  init();

  if(Drive!=NULL)Drive->stop();
  if(S!=NULL)S->stop();
  //task* S=new task(slew);
  task* P=new task(drive_control);
  P->resume();
  add=10;
  //P->resume();
  while (true) {
    run();
  }
}

int main() {
  //Generate Look-Up Table for Gyro Based Turn Correction
  genLookUp(0.07, 0.7);
  genLookUp2(0.07,0.7);
  //  initScreen(); //Initialization for auton selection program

    Competition.autonomous( autonomous );
    Competition.drivercontrol( usercontrol );
    //pre_auton();
                 
     inertial::quaternion  Inertial_quaternion;

    InertialStartCal();

    while(1) {
        // get the quaternion data
        Inertial_quaternion = Inertial.orientation();

        Brain.Screen.clearScreen();        

        Brain.Screen.setFont( mono15 );
        Brain.Screen.setPenColor( white );
        Brain.Screen.setFillColor( black );
        
        Brain.Screen.printAt( 20,  30, "GX  %8.3f", Inertial.gyroRate( xaxis, dps ) );
        Brain.Screen.printAt( 20,  45, "GY  %8.3f", Inertial.gyroRate( yaxis, dps ) );
        Brain.Screen.printAt( 20,  60, "GZ  %8.3f", Inertial.gyroRate( zaxis, dps ) );

        Brain.Screen.printAt( 20,  90, "AX  %8.3f", Inertial.acceleration( xaxis ) );
        Brain.Screen.printAt( 20, 105, "AY  %8.3f", Inertial.acceleration( yaxis ) );
        Brain.Screen.printAt( 20, 120, "AZ  %8.3f", Inertial.acceleration( zaxis ) );

        Brain.Screen.printAt( 20, 150, "A   %8.3f", Inertial_quaternion.a );
        Brain.Screen.printAt( 20, 165, "B   %8.3f", Inertial_quaternion.b );
        Brain.Screen.printAt( 20, 180, "C   %8.3f", Inertial_quaternion.c );
        Brain.Screen.printAt( 20, 195, "D   %8.3f", Inertial_quaternion.d );

        Brain.Screen.printAt( 150, 30, "Roll     %7.2f", Inertial.roll() );
        Brain.Screen.printAt( 150, 45, "Pitch    %7.2f", Inertial.pitch() );
        Brain.Screen.printAt( 150, 60, "Yaw      %7.2f", Inertial.yaw() );

        Brain.Screen.printAt( 150, 90, "Heading  %7.2f", Inertial.heading() );
        Brain.Screen.printAt( 150,105, "Rotation %7.2f", Inertial.rotation() );

        if( Inertial.isCalibrating() )
          Brain.Screen.printAt( 20,225, "Calibration  In Progress" );
        else
          Brain.Screen.printAt( 20,225, "Calibration  Done" );

        Brain.Screen.render();

        // Allow other tasks to run
        this_thread::sleep_for(10);
    }
}