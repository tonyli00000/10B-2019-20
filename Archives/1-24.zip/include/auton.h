#include "driver.h"
#include "autonFunc.h"
using namespace vex;
#define AUTON_NUM 8
#define LIFT_CONSTANT 1000
#define ROLLER_CONSTANT 210
string auton_description[AUTON_NUM]={"8 Cube Unprotected Red","6 Cube Protected Red","6 Cube Unprotected Red","Prog Skills","8 Cube Unprotected Blue","6 Cube Protected Red","6 Cube Unprotected Red","BLANK"};
void Red1(task*& Drive, task*& S,bool skills=false){
  //    init_auton();
  //  setM(Deploy,-100);
  //  wait(650);
  //  setM(Deploy,0);
    init_auton();
  Drive->resume();
  S->resume();
  
  setRoller(100);
  setM(Lift1,-2);
  driveTile(1.8,50);
  wait(1800);
  drive(0,0);
  wait(50);
  setM(Lift1,0);
  driveTile(-0.66);
  wait(650);
  turnDeg(-42,50);
  wait(950);
  drive(-2500,-3100);
  //velCap=80;
  wait(2000);
  drive(0,0);
  wait(120);
  setM(Lift1,-10);
  driveTile(1.45,60);
  wait(1900);
  drive(0,0);
  wait(120);
  turnDeg(138);
  wait(600);
  
  wait(700);
  setRoller(0);
   drive(0,0);
   wait(100);
   
   
    Deploy.rotateFor(1200,rotationUnits::deg,60,velocityUnits::pct,false);
    drive(1600,1800);
   // driveTile(1.1,80);
   wait(600);
   Roller.rotateFor(-50,rotationUnits::deg,60,velocityUnits::pct,false);
   Roller2.rotateFor(-50,rotationUnits::deg,60,velocityUnits::pct,false);
    wait(700);
     setM(Lift1,0);
     Drive->suspend();
    auton_deploy(8);
  
  Drive->resume();
   setRoller(-40);
  driveTile(-1,30);
   if(!skills)end_auton();
}
//Scratched
void Red2(task*& Drive, task*& S){
     Drive->suspend();
  S->suspend();
     init_auton();
    
   setM(Deploy,0);
   setM(Lift1,0);
  Drive->resume();
  S->resume();
   setRoller(100);
  setM(Deploy,0);
  //wait(1300);
  setRoller(100);
  driveTile(1.32,50);
  wait(1500);
  setRoller(40);
  //driveTile(0.26,80);
  //wait(700);
  driveTile(-0.3,50);
  wait(700);
  setRoller(100);
  
  driveTile(1.0,80);
  wait(1500);
  driveTile(-0.5,100);
  wait(600);
  turnDeg(-35,80);
  wait(700);
  driveTile(0.4,100);
  wait(900);
  driveTile(-0.4,100);
  wait(600);
  turnDeg(30,80);
  wait(800);
  driveTile(-0.88);
  wait(1200);
  turnDeg(85);
  wait(1000);
    driveTile(0.7,100);
  wait(800);
  driveTile(-0.6);
  wait(600);
  turnDeg(-170);
  wait(1300);
  drive(0,0);
  wait(200);
  driveTile(1);

   end_auton();
}
void Red3(task*& Drive, task*& S,bool skills=false){
//  Drive->suspend();
//   S->suspend();
//     //setLeft(-10);
//     //setRight(-10);
//     init_auton();
//     //wait(250);
//     //setM(Deploy,-80);
//   wait(250);
//   setM(Deploy,0);
//   wait(150);
//     setRoller(100);
//   setRoller(100);
//   Drive->resume();
//   S->resume();
//   //setM(Deploy,100);
//   get4cubes_straight();
//   turnDeg(-30,80);
//   wait(700);
//   driveTile(0.6,90);
//   wait(840);
//   driveTile(-0.6,90);
//   wait(720);
//   turnDeg(27,80);
//   wait(700);
//   driveTile(-0.9,60);
//   wait(1000);
//   turnDeg(130,100);
//   coast(Roller);
//   coast(Roller2);
//   Roller.startRotateFor(-240,rotationUnits::deg,-180,velocityUnits::pct);
//   Roller2.startRotateFor(-240,rotationUnits::deg,-180,velocityUnits::pct);
//   wait(1200);
  
//    stop_drive();
//   driveTile(0.92,100);
//    Deploy.startRotateFor(300,rotationUnits::deg);
//   setRoller(1);
//    wait(950);
//    setRoller(-10);
//    Drive->suspend();
//    S->suspend();
//    setLeft(-45);
//    setRight(-45);
//    wait(120);
//    setLeft(0);
//    setRight(0);
//    setRoller(0);
//    wait(200);
//    setRoller(-35);
//    wait(260);
//    setRoller(0);
//    auton_deploy(1);
//   hold(Deploy);
  
//   setRoller(-50);
//   wait(150);
//    setLeft(-30);
//    setRight(-30);
  drive(1550,2000);
   end_auton();
}
//Prog Skills
void Red4(task*& Drive, task*& S){
  Drive->suspend();
  S->suspend();
  init_auton();
   
  Drive->resume();
  S->resume();
  
  setRoller(100);
  setM(Lift1,0);
  driveTile(1.8,42);
  wait(3500);
  drive(0,0);
  wait(120);
     setRoller(0);
   wait(800);

  //SECOND TOWER

   lift_low();
  turnDeg(35,50);
   wait(1300);

        driveTile(0.15,30);
  wait(1200);
  // //FIRST TOWER
  // setRoller(-50);
  setRoller(-60);
  //wait(1300);
  wait(1300);
    driveTile(-0.15,30);
  wait(1200);
  turnDeg(-33.5,50);
  wait(1300);
  

  setRoller(100);
  LIFT2();
  driveTile(2.0,53);
  wait(1200);
 // velCap=34;
  wait(2300);

  turnDeg(-42,30);;
  wait(1300);
  setRoller(0);
  wait(400);
  lift_high();
  driveTile(0.34,30);
  wait(2200);
  setRoller(-60);
  wait(1200);
  //SECOND TOWER
driveTile(-0.34,30);
  LIFT2();
  setRoller(100);
  wait(1200);
  turnDeg(39,30);
  wait(1500);
  driveTile(-3.12,50);
  wait(5500);
  turnDeg(-80,50);
  wait(1600);
   //driveTile(0.15,30);
  ///wait(1200);
  //SECOND TOWER
//driveTile(-0.15,30);
  //wait(1200);
  turnDeg(28,34);
  wait(2000);
  driveTile(-1.05,40);
  wait(2000);
  turnDeg(52,35);
  wait(2000);
  driveTile(1.5,36);
  wait(3000);
  driveTile(-0.8,30);
  wait(2000);
  turnDeg(117.5,50);
  wait(2000);
  driveTile(0.5,40);
  wait(1600);
  setRoller(0);
  wait(400);
    Drive->suspend();
  S->suspend();
  setLeft(-30);
  setRight(-30);
  wait(200);
  setLeft(0);
  setRight(0);
     Roller.rotateFor(-80,rotationUnits::deg,60,velocityUnits::pct,false);
   Roller2.rotateFor(-80,rotationUnits::deg,60,velocityUnits::pct,false);
   wait(700);
  Deploy.rotateFor(1050,rotationUnits::deg,60,velocityUnits::pct,false);
  wait(2000);

  
  //setRight(-30);
  wait(200);

  auton_deploy(0);
  setRoller(-40);
  driveTile(-2,30);
  end_auton();
}
void Blue1(task*& Drive, task*& S){
    init_auton();
  Drive->resume();
  S->resume();
  
  setRoller(100);
  setM(Lift1,-2);
  driveTile(1.8,50);
  wait(1800);
  drive(0,0);
  wait(50);
  setM(Lift1,0);
  driveTile(-0.66);
  wait(650);
  turnDeg(42,50);
  wait(950);
  drive(-2500,-3100);
  //velCap=80;
  wait(2000);
  drive(0,0);
  wait(120);
  setM(Lift1,-10);
  driveTile(1.45,60);
  wait(1900);
  drive(0,0);
  wait(120);
  turnDeg(-140,50);
  wait(600);
  
  wait(1000);
  setRoller(0);
   drive(0,0);
   wait(10);
   
   
    Deploy.rotateFor(1200,rotationUnits::deg,60,velocityUnits::pct,false);
    drive(1830,1600);
   // driveTile(1.1,80);
   wait(600);
   Roller.rotateFor(-50,rotationUnits::deg,60,velocityUnits::pct,false);
   Roller2.rotateFor(-50,rotationUnits::deg,60,velocityUnits::pct,false);
    wait(700);
     setM(Lift1,0);
     Drive->suspend();
    auton_deploy(8);
  
  Drive->resume();
   setRoller(-40);
  driveTile(-1,30);
   end_auton();
}
void Blue2(task*& Drive, task*& S){
   Drive->suspend();
  S->suspend();
     init_auton();
    
   setM(Deploy,0);
   setM(Lift1,0);
  Drive->resume();
  S->resume();
   setRoller(100);
  setM(Deploy,0);
  //wait(1300);
  setRoller(100);
  driveTile(1.32,50);
  wait(1500);
  setRoller(40);
  //driveTile(0.26,80);
  //wait(700);
  driveTile(-0.3,50);
  wait(700);
  setRoller(100);
  
  driveTile(1.0,80);
  wait(1500);
  driveTile(-0.5,100);
  wait(600);
  turnDeg(30,80);
  wait(700);
  driveTile(0.4,100);
  wait(900);
  driveTile(-0.4,100);
  wait(600);
  turnDeg(-35,80);
  wait(800);
  driveTile(-0.88);
  wait(1200);
  turnDeg(-85);
  wait(1000);
    driveTile(0.7,100);
  wait(800);
  driveTile(-0.6);
  wait(600);
  turnDeg(170);
  wait(1300);
  drive(0,0);
  wait(200);
  driveTile(1);

   end_auton();
}
void Blue3(task*& Drive, task*& S,bool skills=false){
  Drive->suspend();
  S->suspend();
    setLeft(-10);
    setRight(-10);
    init_auton();
    //wait(250);
    //setM(Deploy,-80);
  wait(250);
  setM(Deploy,0);
  wait(150);
    setRoller(100);
  setRoller(100);
  Drive->resume();
  S->resume();
  //setM(Deploy,100);
  get4cubes_straight();
  turnDeg(30,80);
  wait(700);
  driveTile(0.6,90);
  wait(840);
  driveTile(-0.6,90);
  wait(720);
  turnDeg(-27,80);
  wait(700);
  driveTile(-0.9,60);
  wait(1000);
  turnDeg(-130,100);
  coast(Roller);
  coast(Roller2);
  Roller.startRotateFor(-240,rotationUnits::deg,-180,velocityUnits::pct);
  Roller2.startRotateFor(-240,rotationUnits::deg,-180,velocityUnits::pct);
  wait(1200);
  
   stop_drive();
  driveTile(0.92,100);
   Deploy.startRotateFor(300,rotationUnits::deg);
  setRoller(1);
   wait(950);
   setRoller(-10);
   Drive->suspend();
   S->suspend();
   setLeft(-45);
   setRight(-45);
   wait(120);
   setLeft(0);
   setRight(0);
   setRoller(0);
   wait(200);
   setRoller(-35);
   wait(260);
   setRoller(0);
   auton_deploy(1);
  hold(Deploy);
  
  setRoller(-50);
  wait(150);
   setLeft(-30);
   setRight(-30);
   end_auton();
}
void Blue4(task*& Drive, task*& S){
hold(Deploy);
    Deploy.rotateFor(310,rotationUnits::deg,false),wait(200);
    //hold(Lift1);
    Lift1.rotateFor(850,rotationUnits::deg,100,velocityUnits::pct);
    wait(4800);
  end_auton();
}