#include "driver.h"
#include "autonFunc.h"
using namespace vex;
#define AUTON_NUM 8
#define LIFT_CONSTANT 1000
#define ROLLER_CONSTANT 210

void Red1(task*& Drive, task*& S,bool skills=false){
  Drive->suspend();
  S->suspend();
   init_auton();
   Drive->resume();
   S->resume();
   setRoller(100);
   driveTile(1.78,37);
   wait(2700);
   setRoller(100);
   //setM(Lift1,0);
  drive(0,0);
  wait(100);
  setRoller(100);
  turnDeg(-21,40);
  wait(700);
  
  driveTile(0.4,30);
  wait(700);
  //driveTile(-0.2,50);
  wait(200);
  driveTile(-0.1,35);
  wait(550);
  turnDeg(25,60);
  wait(860);
  driveTile(0.34,40);
  wait(600);
  driveTile(-1.05,60);

 wait(650);
      setRoller(-50);
 //setRoller(-50);
 wait(300);
 setRoller(0);
  wait(250);
  setRoller(0);
  turnDeg(133,64);

 setRoller(0);
  wait(1300);
  drive(0,0);
  wait(50);
  driveTile(1.1,70);
 setM(Deploy,20);
wait(350);
 setRoller(0);
  //Roller.rotateFor(-110,rotationUnits::deg,65,velocityUnits::pct);
  //Roller2.rotateFor(-110,rotationUnits::deg,65,velocityUnits::pct);
  wait(750);
  Drive->suspend();
  S->suspend();
  setLeft(-0);
  setRight(-0);
  wait(0);
  setLeft(0);
  setRight(0);
  auton_deploy(0);
  setM(Deploy,0);
  setLeft(-50);
  setRight(-50);
  end_auton();
   end_auton();
}
//Scratched
void Red2(task*& Drive, task*& S){

     init_auton();
    
  // setM(Deploy,0);
   //setM(Lift1,0);
  //Drive->resume();
  //S->resume();
  setRoller(100);
  driveTile(0.81,70);
  wait(1000);
  drive(0,0);
  wait(100);
  turnDeg(87,80);
  wait(1000);
  driveTile(0.3,40);
  wait(900);
  turnDeg(18);
  wait(600);
  driveTile(0.3);
  wait(700);

  driveTile(-0.6,50);
  wait(1000);
  turnDeg(-191);
wait(1300);
driveTile(1.2,50);
wait(1200);
turnDeg(-49);
wait(700);
setRoller(0);
driveTile(0.42,60);
wait(800);
setRoller(-50);
wait(430);

setRoller(0);
Drive->suspend();
S->suspend();
//setLeft(-30);
//setRight(-30);
wait(210);
setLeft(0);
setRight(0);
auton_deploy(0,true);
Drive->resume();
S->resume();
driveTile(-0.9,40);
   end_auton();
}
void Red3(task*& Drive, task*& S,bool skills=false){
Drive->suspend();
  S->suspend();
   init_auton();
   Drive->resume();
   S->resume();
   setRoller(100);
   driveTile(2.2,45);
   wait(2500);
   driveTile(0.25,40);
   wait(850);
  driveTile(-0.57,70);
  wait(800);
  turnDeg(-26,40);
  wait(700);
  
  driveTile(0.23,30);
  wait(700);
  //driveTile(-0.2,50);
  wait(100);
  turnDeg(28,50);
  wait(600);
  driveTile(-0.83,60);
  wait(1000);
  setRoller(0);
  turnDeg(135.4,60);
  wait(1500);
  driveTile(0.75,80);
 setM(Deploy,40);
  Roller.rotateFor(-110,rotationUnits::deg,65,velocityUnits::pct);
  Roller2.rotateFor(-110,rotationUnits::deg,65,velocityUnits::pct);
  wait(800);
  Drive->suspend();
  S->suspend();
  setLeft(-20);
  setRight(-20);
  wait(120);
  setLeft(0);
  setRight(0);
  auton_deploy(0);
  setM(Deploy,0);
  setLeft(-50);
  setRight(-50);
  end_auton();
   end_auton();
}
//Prog Skills
void Red4(task*& Drive, task*& S){
  hold(Roller);
  hold(Roller2);
  add=25;
  Drive->suspend();
  S->suspend();
  
  init_auton(); //Auton Deploy
  
  //Wall Align
   setLeft(-20);
   setRight(-20);
   wait(600);
   setLeft(0);
   setRight(0);
   wait(100);
  Drive->resume();
  S->resume();
  
  setRoller(100);
  /*Do first tower if there's enough time*/
  // cube_lock=false;
  // wait(500);
  // setRoller(0);
  // turnDeg(40);
  // lift_low();
  // wait(500);
  // driveTile(0.9);
  // wait(900);
  // setRoller(-100);
  // wait(500);
  //   driveTile(-0.9);
  // wait(900);
  // turnDeg(-37);
  // wait(900);
  // LIFT2();
  cube_lock=true;
  
  /*First Line of Cube*/
  setM(Lift1,-2);
  driveTile(1.805,40);
  wait(3700);
  drive(0,0);
  wait(400);
  setRoller(0);
  wait(400);

  /*First Tower*/
  LIFT(430,true,1400);
  turnDeg(-18);
  wait(900);
  driveTile(0.12,100);
  wait(400);
  setRoller(-90);
  wait(600);
  driveTile(-0.12);
  wait(600);
  turnDeg(31.5);
  wait(540);
  setRoller(100);
  LIFT2();
  setM(Lift1,-100);
  wait(280);
  setM(Lift1,0);
  /*Second Line*/
  driveTile(0.44,40);
  wait(900);
  turnDeg(-11,50);
  wait(800);
  setM(Lift1,0);
  driveTile(2.27,45);
  wait(4000);
  drive(0,0);
  wait(1500);
  setRoller(0);
  wait(120);
  driveTile(-0.27,60);
  setRoller(0);
  hold(Roller);
  hold(Roller2);
  wait(700);

  /*Second Tower*/
    lift_low();

  turnDeg(89.5,60);
  wait(1150);
  setRoller(-80);
  wait(700);
  turnDeg(-87,70);
  wait(930);
  setRoller(100);
  LIFT2();
  setM(Lift1,-100);
  wait(200);
  setM(Lift1,0);
  driveTile(0.67,60);
  wait(1000);
  driveTile(-0.13,60);
  wait(500);
  turnDeg(45);
  wait(1000);
  driveTile(0.60);
  wait(1200);
  setRoller(0);

  //Deploy
     Drive->suspend();
   S->suspend();
   setLeft(-20);
   setRight(-20);
   wait(100);
   setLeft(0);
   setRight(0);

   setM(Lift1,-3);
       Roller.rotateFor(-140,rotationUnits::deg,80,velocityUnits::pct,false);
   Roller2.rotateFor(-140,rotationUnits::deg,80,velocityUnits::pct,false);
   wait(700);

  auton_deploy(3,true);
  Drive->resume();
  S->resume();
   driveTile(-0.47,60);
  wait(400);
  setM(Deploy,-100);
  wait(1550);
  setM(Deploy,0);
  turnDeg(-40);
  wait(900);
  lift_low();
  wait(500);
       Drive->suspend();
   S->suspend();
  setLeft(100);
  setRight(100);
  wait(900);
  setLeft(4);
  setRight(4);
  wait(300);
  Drive->resume();
  S->resume();
  driveTile(-0.45,50);
  wait(800);
  LIFT2();
  hold(Lift1);
  setM(Lift1,-30);
  turnDeg(-85.4,40);
  wait(500);
  setM(Lift1,0);
  wait(1040);
  
  /*Third Tower*/
  setM(Deploy,0);
  setRoller(100);
  driveTile(1.2,60);
  wait(1440);
  driveTile(-0.15);
  
  wait(600);

  /*Third Tower*/
  //setRoller(-30);
  
  //wait(210);
  setRoller(0);
  //cube_lock=false;
  LIFT(700,true,1500);
  //wait(150);
  driveTile(0.3,100);
  wait(500);
  setRoller(-70);
  wait(600);
  driveTile(-0.22);
  wait(900);
  LIFT2();
  wait(200);
  turnDeg(-87,50);
  wait(1100);
  //driveTile(-0.5,60);
  setRoller(100);
  
  driveTile(-0.4,60);
  //wait(500);
  //LIFT2();
  //wait(300);
  cube_lock=true;
  
  driveTile(3.5,60);
  wait(4400);
  turnDeg(-51.4);
  wait(1100);
  //setRoller(0);
  driveTile(1.74,74);
  wait(1050);
  //setM(Deploy,40);

  wait(1700);
  setRoller(0);
    Roller.rotateFor(-135,rotationUnits::deg,65,velocityUnits::pct,false);
  Roller2.rotateFor(-135,rotationUnits::deg,65,velocityUnits::pct,false);
  Drive->suspend();
  S->suspend();
  setLeft(0);
  setRight(0);
  //wait(100);
  setM(Deploy,60);
  wait(600);
  auton_deploy(0);
  setM(Deploy,0);
  setLeft(-50);
  setRight(-50);
  end_auton();
  end_auton();
}
void Blue1(task*& Drive, task*& S){
  Drive->suspend();
  S->suspend();
   init_auton();
   Drive->resume();
   S->resume();
   setM(Lift1,-80);
   setRoller(100);
   driveTile(1.8,40);
   wait(150);
   setM(Lift1,0);
   wait(2150);
    //drive(0,0);
    wait(200);
  turnDeg(28,40);
  wait(700);
  
  driveTile(0.29,40);
  wait(700);
  //driveTile(-0.2,50);
  wait(300);
  driveTile(-0.17,30);
  wait(300);
  turnDeg(-26,60);
  wait(800);
  driveTile(0.37,30);
  wait(800);
  driveTile(-1.15,70);
  wait(1200);
  turnDeg(-123.34,47);
  wait(1050);
   setRoller(-50);
 // Roller.rotateFor(-110,rotationUnits::deg,65,velocityUnits::pct);
  //Roller2.rotateFor(-110,rotationUnits::deg,65,velocityUnits::pct);
  wait(300);
  setRoller(0);
  drive(0,0);
  wait(100);
  driveTile(1.06,55);
 setM(Deploy,40);

  
  wait(800);
  Drive->suspend();
  S->suspend();
  setLeft(0);
  setRight(0);
  wait(50);
  setLeft(0);
  setRight(0);
  auton_deploy(0);
  setM(Deploy,0);
  setLeft(-50);
  setRight(-50);
  end_auton();
   end_auton();
}
void Blue2(task*& Drive, task*& S){
     init_auton();
    
  // setM(Deploy,0);
   //setM(Lift1,0);
  //Drive->resume();
  //S->resume();
  //setM(Lift1,-4);
  setRoller(100);
  driveTile(0.81,70);
  wait(1200);
  drive(0,0);
  wait(100);
  turnDeg(-84,80);
  wait(1200);
  driveTile(0.3,40);
  wait(900);
  driveTile(-0.3,50);
  wait(1000);
  turnDeg(164);
wait(1300);
driveTile(1.1,50);
wait(1200);
turnDeg(64);
wait(900);
setRoller(0);
driveTile(0.4,50);
wait(1000);
setRoller(-20);
wait(430);

setRoller(0);
Drive->suspend();
S->suspend();
//setLeft(-30);
//setRight(-30);
wait(210);
setLeft(0);
setRight(0);
auton_deploy(0,true);
Drive->resume();
S->resume();
driveTile(-0.9,40);
   end_auton();
}
void Blue3(task*& Drive, task*& S,bool skills=false){
Drive->suspend();
  S->suspend();
   init_auton();
   Drive->resume();
   S->resume();
   setRoller(100);
   driveTile(1.8,45);
   wait(2400);

  turnDeg(26,40);
  wait(700);
  
  driveTile(0.23,30);
  wait(700);
  //driveTile(-0.2,50);
  wait(100);
  driveTile(-0.14,30);
  wait(500);
  turnDeg(-23,60);
  wait(800);
  driveTile(0.4,30);
  wait(800);
  driveTile(-1.15,60);
  wait(1000);
  setRoller(0);
  turnDeg(-139,60);
  wait(1500);
  driveTile(1,80);
 setM(Deploy,40);
  Roller.rotateFor(-110,rotationUnits::deg,65,velocityUnits::pct);
  Roller2.rotateFor(-110,rotationUnits::deg,65,velocityUnits::pct);
  wait(800);
  Drive->suspend();
  S->suspend();
  setLeft(-20);
  setRight(-20);
  wait(120);
  setLeft(0);
  setRight(0);
  auton_deploy(0);
  setM(Deploy,0);
  setLeft(-50);
  setRight(-50);
  end_auton();
   end_auton();
}
void Blue4(task*& Drive, task*& S,Odom& BDOM){
  BDOM.reset();
   Drive->suspend();
  S->suspend();
  init_auton();
  Drive->resume();
  S->resume();
  setRoller(100);
  driveTile(0.90,35);
  wait(1400);
  setRoller(0);
  driveTile(0.14,23);
  //wait(200);
  setRoller(100);
  wait(200);
 // BDOM.Odom_straight(1600, 1600, 3000, 99);

 turnDeg(-50,60);
  wait(800);

  driveTile(-1.64,60);
  wait(1300);
  turnDeg(52.3,60);
  wait(900);
  driveTile(1.1,50);
  wait(1000);

  //BDOM.Odom_turn(0,1100);
  //Drive->resume();
  //S->resume();
  //drive(0,0);
  //BDOM.Odom_spline(30,-20,false,15000);
  end_auton();
}